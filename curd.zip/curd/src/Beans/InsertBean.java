package Beans;

public class InsertBean {
	private String id;
private String user;
private String email;
private String gender;
private long mobile;

private String address;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getUser() {
	return user;
}
public void setUser(String user) {
	this.user = user;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}

public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public InsertBean() {
	super();
	// TODO Auto-generated constructor stub
}



}