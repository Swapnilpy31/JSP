package dao;

import java.sql.CallableStatement;
import java.sql.Connection;

import Beans.InsertBean;
import DBconnection.DBConnection;

public class InsertDao {
	public static int insert(InsertBean ibean){
		
		int x=0;
		try{
			Connection conn= DBConnection .getconnection();
			CallableStatement ps= conn.prepareCall("{call INSERT_EMP(?,?,?,?,?,?)}");		
			ps.setString(1, ibean.getUser());
			ps.setString(2, ibean.getGender());
			ps.setNString(3, ibean.getEmail());
			ps.setLong(4, ibean.getMobile());
			ps.setString(5, ibean.getAddress());
			ps.setString(6, ibean.getId());
			x=ps.executeUpdate();
			System.out.println(x);
			ps.close();
			conn.close();
			if(x==0)
			{
				System.out.println("Data Inserted");
			}
			else
				System.out.println("Something wrong");
		
		}
		catch(Exception e){
			
		}
		
		return x;
		
	}

}
